# Add project specific ProGuard rules here.
-keep class com.goalcanvas.ai.data.local.** { *; }
