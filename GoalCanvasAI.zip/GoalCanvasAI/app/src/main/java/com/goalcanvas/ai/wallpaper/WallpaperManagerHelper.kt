package com.goalcanvas.ai.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

enum class WallpaperTarget { HOME, LOCK, BOTH }

@Singleton
class WallpaperManagerHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val manager: WallpaperManager by lazy { WallpaperManager.getInstance(context) }

    /** Sets [bitmap] as the wallpaper for [target]. No manual steps required afterward. */
    fun apply(bitmap: Bitmap, target: WallpaperTarget) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            when (target) {
                WallpaperTarget.HOME -> manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                WallpaperTarget.LOCK -> manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
                WallpaperTarget.BOTH -> manager.setBitmap(
                    bitmap, null, true,
                    WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                )
            }
        } else {
            // Pre-N devices don't support a separate lock screen wallpaper API.
            manager.setBitmap(bitmap)
        }
    }
}
