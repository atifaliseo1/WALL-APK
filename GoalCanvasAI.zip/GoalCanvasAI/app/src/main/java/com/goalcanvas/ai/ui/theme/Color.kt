package com.goalcanvas.ai.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

val AccentGold = Color(0xFFE9C46A)
val SurfaceDark = Color(0xFF0B0B0F)
val SurfaceElevated = Color(0xFF17171E)
val OnSurfaceLight = Color(0xFFF5F1E6)
val OnSurfaceMuted = Color(0xFFB8B4A8)

val GoalCanvasDarkScheme = darkColorScheme(
    primary = AccentGold,
    onPrimary = Color.Black,
    background = SurfaceDark,
    onBackground = OnSurfaceLight,
    surface = SurfaceElevated,
    onSurface = OnSurfaceLight,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = OnSurfaceMuted
)
