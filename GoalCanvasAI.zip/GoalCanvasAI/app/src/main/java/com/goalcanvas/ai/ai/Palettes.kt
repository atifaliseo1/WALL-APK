package com.goalcanvas.ai.ai

/**
 * A curated set of premium-feeling palettes. Curation matters here: fully random RGB values
 * tend to look muddy or clash. Picking from a hand-tuned set (then randomizing gradient
 * angle/typography/layout/effects on top) is what keeps every wallpaper looking "designed"
 * rather than "randomly generated."
 */
object Palettes {
    val all: List<ColorPalette> = listOf(
        ColorPalette(
            name = "Midnight Gold",
            backgroundGradient = listOf(0xFF05060AL, 0xFF14131BL, 0xFF2A2113L),
            accent = 0xFFE9C46AL,
            textPrimary = 0xFFF5F1E6L,
            textSecondary = 0xFFC9BFA3L,
            glow = 0xFFE9C46AL
        ),
        ColorPalette(
            name = "Neon Violet",
            backgroundGradient = listOf(0xFF0B0714L, 0xFF1D0F3CL, 0xFF3A0F63L),
            accent = 0xFFB94EF0L,
            textPrimary = 0xFFF1E9FFL,
            textSecondary = 0xFFC8AEE6L,
            glow = 0xFFB94EF0L
        ),
        ColorPalette(
            name = "Ember Red",
            backgroundGradient = listOf(0xFF0A0505L, 0xFF2A0B0BL, 0xFF4D1010L),
            accent = 0xFFFF5A36L,
            textPrimary = 0xFFFFF3EEL,
            textSecondary = 0xFFE8B7A6L,
            glow = 0xFFFF5A36L
        ),
        ColorPalette(
            name = "Arctic Steel",
            backgroundGradient = listOf(0xFF05080AL, 0xFF10222BL, 0xFF163847L),
            accent = 0xFF5AD1E6L,
            textPrimary = 0xFFEAF7FAL,
            textSecondary = 0xFFA9CBD4L,
            glow = 0xFF5AD1E6L
        ),
        ColorPalette(
            name = "Emerald Wealth",
            backgroundGradient = listOf(0xFF040A07L, 0xFF0E241AL, 0xFF163D29L),
            accent = 0xFF3DDC84L,
            textPrimary = 0xFFEFFAF3L,
            textSecondary = 0xFFAED9BEL,
            glow = 0xFF3DDC84L
        ),
        ColorPalette(
            name = "Rose Ambition",
            backgroundGradient = listOf(0xFF0B0507L, 0xFF2B0F1AL, 0xFF44172AL),
            accent = 0xFFFF6FA5L,
            textPrimary = 0xFFFFEFF4L,
            textSecondary = 0xFFE4B4C5L,
            glow = 0xFFFF6FA5L
        ),
        ColorPalette(
            name = "Solar Discipline",
            backgroundGradient = listOf(0xFF0A0602L, 0xFF2E1B04L, 0xFF5C3508L),
            accent = 0xFFFFA733L,
            textPrimary = 0xFFFFF6E8L,
            textSecondary = 0xFFE0C39CL,
            glow = 0xFFFFA733L
        ),
        ColorPalette(
            name = "Deep Ocean",
            backgroundGradient = listOf(0xFF020508L, 0xFF071B2EL, 0xFF0B3050L),
            accent = 0xFF4FA8FFL,
            textPrimary = 0xFFEAF3FFL,
            textSecondary = 0xFFA9C3E0L,
            glow = 0xFF4FA8FFL
        )
    )

    fun random() = all.random()
}
