package com.goalcanvas.ai.ai

import android.graphics.Bitmap

/** Result of trying to source a background image for a [DesignSpec]. */
sealed class BackgroundResult {
    data class Remote(val bitmap: Bitmap) : BackgroundResult()
    data class Fallback(val bitmap: Bitmap) : BackgroundResult()
}

interface ImageGenerationService {
    /**
     * Attempts to fetch/generate a background image for [spec]. Implementations must never
     * throw - on any failure (no network, no API key configured, timeout, non-200 response)
     * they should fall back to a locally rendered background so the app always produces a
     * finished wallpaper.
     */
    suspend fun generateBackground(spec: DesignSpec, widthPx: Int, heightPx: Int): BackgroundResult
}
