package com.goalcanvas.ai.wallpaper

import android.content.Context
import android.graphics.Bitmap
import androidx.core.content.FileProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WallpaperFileStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dir: File by lazy {
        File(context.filesDir, "wallpapers").apply { mkdirs() }
    }

    fun save(bitmap: Bitmap): File {
        val file = File(dir, "wallpaper_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file
    }

    fun shareUri(file: File) = FileProvider.getUriForFile(
        context, "com.goalcanvas.ai.fileprovider", file
    )

    fun delete(path: String) {
        File(path).takeIf { it.exists() }?.delete()
    }
}
