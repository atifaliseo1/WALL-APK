package com.goalcanvas.ai.data.repository

import android.graphics.Bitmap
import com.goalcanvas.ai.ai.BackgroundResult
import com.goalcanvas.ai.ai.DesignSpec
import com.goalcanvas.ai.ai.ImageGenerationService
import com.goalcanvas.ai.ai.PromptBuilder
import com.goalcanvas.ai.data.local.WallpaperDao
import com.goalcanvas.ai.data.local.WallpaperEntity
import com.goalcanvas.ai.wallpaper.WallpaperCompositor
import com.goalcanvas.ai.wallpaper.WallpaperFileStore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

data class GeneratedWallpaper(
    val bitmap: Bitmap,
    val spec: DesignSpec,
    val usedRemoteAi: Boolean
)

@Singleton
class WallpaperRepository @Inject constructor(
    private val imageGenerationService: ImageGenerationService,
    private val fileStore: WallpaperFileStore,
    private val dao: WallpaperDao
) {
    /** Builds a brand-new design spec and renders it into a finished wallpaper bitmap. */
    suspend fun generate(goals: List<String>, widthPx: Int, heightPx: Int): GeneratedWallpaper {
        val spec = PromptBuilder.build(goals)
        val backgroundResult = imageGenerationService.generateBackground(spec, widthPx, heightPx)
        val background = when (backgroundResult) {
            is BackgroundResult.Remote -> backgroundResult.bitmap
            is BackgroundResult.Fallback -> backgroundResult.bitmap
        }
        val finished = WallpaperCompositor.compose(background, spec)
        return GeneratedWallpaper(
            bitmap = finished,
            spec = spec,
            usedRemoteAi = backgroundResult is BackgroundResult.Remote
        )
    }

    suspend fun saveToHistory(generated: GeneratedWallpaper) {
        val file = fileStore.save(generated.bitmap)
        dao.insert(
            WallpaperEntity(
                filePath = file.absolutePath,
                goalsJoined = generated.spec.goals.joinToString("|"),
                quote = generated.spec.quote,
                createdAtEpochMs = System.currentTimeMillis(),
                backgroundStyle = generated.spec.backgroundStyle.name,
                artStyle = generated.spec.artStyle.name
            )
        )
        dao.pruneBeyondThirty()
    }

    fun observeHistory(): Flow<List<WallpaperEntity>> = dao.observeAll()

    fun observeFavorites(): Flow<List<WallpaperEntity>> = dao.observeFavorites()

    suspend fun toggleFavorite(entity: WallpaperEntity) {
        dao.update(entity.copy(isFavorite = !entity.isFavorite))
    }

    suspend fun delete(entity: WallpaperEntity) {
        fileStore.delete(entity.filePath)
        dao.delete(entity)
    }
}
