package com.goalcanvas.ai.ai

import kotlin.random.Random

/**
 * Turns a raw list of user goals into a full [DesignSpec]: background, art style, palette,
 * typography, layout and effects, plus a rich internal image-generation prompt. The user's
 * goals are never forwarded verbatim to any external service - they're folded into a larger
 * creative brief alongside art direction, lighting, and color psychology.
 */
object PromptBuilder {

    fun build(goals: List<String>): DesignSpec {
        val seed = System.nanoTime() xor Random.nextLong()
        val rnd = Random(seed)

        val background = BackgroundStyle.random()
        val artStyle = ArtStyle.random()
        val palette = Palettes.random()
        val quote = QuoteGenerator.generate(goals, seed)

        val typography = TypographySpec(
            headlineFontFamily = FontChoice.entries.random(rnd),
            bodyFontFamily = FontChoice.entries.random(rnd),
            headlineSizeSp = listOf(40, 48, 56, 64, 72).random(rnd),
            bodySizeSp = listOf(18, 20, 22, 24).random(rnd),
            letterSpacing = listOf(0f, 0.5f, 1f, 2f).random(rnd),
            allCapsHeadline = rnd.nextBoolean(),
            rotationDegrees = listOf(0f, 0f, 0f, -4f, 4f, -8f).random(rnd) // mostly straight, occasionally tilted
        )

        val layout = LayoutSpec(
            composition = Composition.entries.random(rnd),
            goalsAsChecklist = rnd.nextBoolean(),
            quotePlacement = VerticalAnchor.entries.random(rnd),
            goalsPlacement = VerticalAnchor.entries.random(rnd),
            horizontalBias = listOf(0f, 0.15f, 0.5f, 0.85f, 1f).random(rnd)
        )

        val effects = EffectSpec(
            glowIntensity = rnd.nextFloat() * 0.6f + 0.2f,
            shadowIntensity = rnd.nextFloat() * 0.5f + 0.3f,
            grainIntensity = rnd.nextFloat() * 0.15f,
            vignette = rnd.nextFloat() > 0.3f,
            noiseTexture = rnd.nextFloat() > 0.5f
        )

        val imagePrompt = buildImagePrompt(goals, background, artStyle, palette, quote)

        return DesignSpec(
            goals = goals,
            quote = quote,
            backgroundStyle = background,
            artStyle = artStyle,
            palette = palette,
            typography = typography,
            layout = layout,
            effects = effects,
            imagePrompt = imagePrompt,
            seed = seed
        )
    }

    /**
     * Composes the full creative brief sent to a remote image-generation API (if one is
     * configured). This mixes art direction, lighting, composition, and color psychology
     * intent, rather than a literal echo of what the user typed.
     */
    private fun buildImagePrompt(
        goals: List<String>,
        background: BackgroundStyle,
        artStyle: ArtStyle,
        palette: ColorPalette,
        quote: String
    ): String {
        val moodFromGoals = when {
            goals.any { it.contains("gym", true) || it.contains("run", true) || it.contains("workout", true) } ->
                "energetic, disciplined, physical intensity"
            goals.any { it.contains("pray", true) || it.contains("meditat", true) } ->
                "calm, grounded, reflective stillness"
            goals.any { it.contains("client", true) || it.contains("sale", true) || it.contains("business", true) } ->
                "ambitious, sharp, high-status confidence"
            else -> "focused, premium, cinematic motivation"
        }

        return buildString {
            append("Ultra HD 8K cinematic wallpaper, ")
            append("${background.label}, ")
            append("${artStyle.descriptor}, ")
            append("dynamic lighting, volumetric light, high contrast, depth of field, ")
            append("mood: $moodFromGoals, ")
            append("color palette inspired by ${palette.name.lowercase()} tones, ")
            append("no readable text baked into the image, leave clean negative space for typography overlay, ")
            append("professional poster composition, no watermark, no logos.")
        }
    }
}
