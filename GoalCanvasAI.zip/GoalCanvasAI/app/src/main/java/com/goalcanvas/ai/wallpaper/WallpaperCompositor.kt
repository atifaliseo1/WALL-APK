package com.goalcanvas.ai.wallpaper

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import com.goalcanvas.ai.ai.Composition
import com.goalcanvas.ai.ai.DesignSpec
import com.goalcanvas.ai.ai.FontChoice
import com.goalcanvas.ai.ai.VerticalAnchor

/** Draws the goal checklist + quote onto a background bitmap according to the [DesignSpec]. */
object WallpaperCompositor {

    fun compose(background: Bitmap, spec: DesignSpec): Bitmap {
        val width = background.width
        val height = background.height
        val result = background.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val headlineTypeface = typefaceFor(spec.typography.headlineFontFamily)
        val bodyTypeface = typefaceFor(spec.typography.bodyFontFamily)

        val textPrimary = spec.palette.textPrimary.toInt()
        val textSecondary = spec.palette.textSecondary.toInt()
        val accent = spec.palette.accent.toInt()
        val glow = spec.palette.glow.toInt()

        val centerX = width * (0.1f + 0.8f * spec.layout.horizontalBias)
        val quoteY = anchorToY(spec.layout.quotePlacement, height)
        val goalsY = anchorToY(spec.layout.goalsPlacement, height)

        canvas.save()
        canvas.rotate(spec.typography.rotationDegrees, centerX, height / 2f)

        // --- Quote / headline ---
        val headlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = headlineTypeface
            textSize = spec.typography.headlineSizeSp * (width / 360f) // scale for device density
            color = textPrimary
            letterSpacing = spec.typography.letterSpacing / 100f
            textAlign = Paint.Align.CENTER
            setShadowLayer(spec.effects.shadowIntensity * 24f, 0f, 6f, 0x99000000.toInt())
        }
        val headlineText = if (spec.typography.allCapsHeadline) spec.quote.uppercase() else spec.quote
        drawWrappedText(canvas, headlineText, centerX, quoteY, width * 0.82f, headlinePaint)

        // Soft glow pass behind the headline for a premium look.
        if (spec.effects.glowIntensity > 0f) {
            val glowPaint = Paint(headlinePaint).apply {
                color = glow
                alpha = (spec.effects.glowIntensity * 90).toInt().coerceIn(0, 255)
                setShadowLayer(40f * spec.effects.glowIntensity, 0f, 0f, glow)
            }
            drawWrappedText(canvas, headlineText, centerX, quoteY, width * 0.82f, glowPaint)
        }

        // --- Goals checklist ---
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = bodyTypeface
            textSize = spec.typography.bodySizeSp * (width / 360f)
            color = textSecondary
            textAlign = Paint.Align.CENTER
            setShadowLayer(spec.effects.shadowIntensity * 14f, 0f, 3f, 0x99000000.toInt())
        }
        val checkPaint = Paint(bodyPaint).apply { color = accent }

        var lineY = goalsY
        val lineHeight = bodyPaint.textSize * 1.7f
        spec.goals.forEachIndexed { index, goal ->
            val prefix = if (spec.layout.goalsAsChecklist) "\u2713  " else "${index + 1}. "
            canvas.drawText(prefix + goal, centerX, lineY, if (spec.layout.goalsAsChecklist) checkPaint else bodyPaint)
            lineY += lineHeight
        }

        canvas.restore()
        return result
    }

    private fun drawWrappedText(canvas: Canvas, text: String, cx: Float, startY: Float, maxWidth: Float, paint: Paint) {
        val words = text.split(" ")
        var line = StringBuilder()
        var y = startY
        val lineHeight = paint.textSize * 1.25f
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                canvas.drawText(line.toString(), cx, y, paint)
                line = StringBuilder(word)
                y += lineHeight
            } else {
                line = StringBuilder(candidate)
            }
        }
        if (line.isNotEmpty()) canvas.drawText(line.toString(), cx, y, paint)
    }

    private fun anchorToY(anchor: VerticalAnchor, height: Int): Float = when (anchor) {
        VerticalAnchor.TOP -> height * 0.15f
        VerticalAnchor.UPPER_MIDDLE -> height * 0.32f
        VerticalAnchor.CENTER -> height * 0.5f
        VerticalAnchor.LOWER_MIDDLE -> height * 0.68f
        VerticalAnchor.BOTTOM -> height * 0.85f
    }

    private fun typefaceFor(choice: FontChoice): Typeface = when (choice) {
        FontChoice.SANS_BOLD -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        FontChoice.SANS_LIGHT -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        FontChoice.SERIF -> Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        FontChoice.SERIF_ITALIC -> Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        FontChoice.MONOSPACE -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        FontChoice.CONDENSED -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
    }
}
