package com.goalcanvas.ai.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.goalcanvas.ai.data.local.WallpaperEntity
import com.goalcanvas.ai.ui.WallpaperViewModel
import android.graphics.BitmapFactory

@Composable
fun HistoryScreen(
    favoritesOnly: Boolean,
    onBack: () -> Unit,
    viewModel: WallpaperViewModel = hiltViewModel()
) {
    val history by (if (favoritesOnly) viewModel.favorites else viewModel.history).collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (favoritesOnly) "Favorites" else "History") }) }
    ) { padding ->
        if (history.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (favoritesOnly) "No favorites yet." else "No saved wallpapers yet.",
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            return@Scaffold
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            items(history, key = { it.id }) { entity ->
                HistoryTile(entity, viewModel)
            }
        }
    }
}

@Composable
private fun HistoryTile(entity: WallpaperEntity, viewModel: WallpaperViewModel) {
    Column {
        val bitmap = remember(entity.filePath) { BitmapFactory.decodeFile(entity.filePath) }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = entity.quote,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(9f / 16f)
                    .clip(RoundedCornerShape(16.dp))
            )
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = { viewModel.toggleFavorite(entity) }) {
                Icon(
                    if (entity.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Toggle favorite"
                )
            }
            IconButton(onClick = { viewModel.deleteFromHistory(entity) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete")
            }
        }
    }
}
