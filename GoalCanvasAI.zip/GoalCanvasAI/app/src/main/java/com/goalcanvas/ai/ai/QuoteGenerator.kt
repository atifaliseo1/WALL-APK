package com.goalcanvas.ai.ai

/**
 * Produces a fresh motivational line every call. Rather than a fixed list (which would repeat
 * within ~50 generations), this composes from independent word banks so the combinatorial space
 * is huge, and leans on the user's own goal keywords so the line feels tied to today specifically.
 */
object QuoteGenerator {

    private val openers = listOf(
        "Discipline beats", "Consistency beats", "Small steps outrun",
        "Today's effort becomes", "What you repeat becomes", "Focus turns into",
        "Show up before", "Earn tomorrow through", "Momentum is built by",
        "The version of you that wins started with"
    )

    private val subjects = listOf(
        "motivation", "excuses", "yesterday's version of you", "comfort",
        "tomorrow's regret", "doubt", "the noise", "average"
    )

    private val closers = listOf(
        "One goal at a time.", "No shortcuts, just reps.", "Prove it today.",
        "Let today speak for you.", "That's the whole game.", "Nothing changes if nothing moves.",
        "Start where you are.", "Action over intention.",
        "The work is the message.", "Bet on yourself again."
    )

    /**
     * @param goals the user's raw goal list, used to keep the quote relevant to today
     * @param seed a per-generation random seed so repeated calls with the same goals still differ
     */
    fun generate(goals: List<String>, seed: Long): String {
        val rnd = kotlin.random.Random(seed)
        val opener = openers.random(rnd)
        val subject = subjects.random(rnd)
        val closer = closers.random(rnd)

        val base = "$opener $subject."
        // Occasionally weave in a real goal keyword to make it feel written *for* today's list.
        val goalKeyword = goals.randomOrNull(rnd)?.split(" ")?.firstOrNull { it.length > 3 }
        return if (goalKeyword != null && rnd.nextBoolean()) {
            "$base $closer Especially when it comes to ${goalKeyword.lowercase()}."
        } else {
            "$base $closer"
        }
    }
}
