package com.goalcanvas.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.goalcanvas.ai.ui.screens.HistoryScreen
import com.goalcanvas.ai.ui.screens.HomeScreen
import com.goalcanvas.ai.ui.theme.GoalCanvasAITheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GoalCanvasAITheme {
                GoalCanvasNavHost()
            }
        }
    }
}

private object Routes {
    const val HOME = "home"
    const val HISTORY = "history"
    const val FAVORITES = "favorites"
}

@Composable
private fun GoalCanvasNavHost() {
    val navController: NavHostController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenHistory = { navController.navigate(Routes.HISTORY) },
                onOpenFavorites = { navController.navigate(Routes.FAVORITES) }
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(favoritesOnly = false, onBack = { navController.popBackStack() })
        }
        composable(Routes.FAVORITES) {
            HistoryScreen(favoritesOnly = true, onBack = { navController.popBackStack() })
        }
    }
}
