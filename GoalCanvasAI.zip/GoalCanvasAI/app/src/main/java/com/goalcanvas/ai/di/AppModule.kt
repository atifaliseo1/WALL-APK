package com.goalcanvas.ai.di

import android.content.Context
import androidx.room.Room
import com.goalcanvas.ai.ai.ImageGenerationService
import com.goalcanvas.ai.ai.RemoteImageGenerationService
import com.goalcanvas.ai.data.local.AppDatabase
import com.goalcanvas.ai.data.local.WallpaperDao
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "goalcanvas.db").build()

    @Provides
    fun provideWallpaperDao(db: AppDatabase): WallpaperDao = db.wallpaperDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class BindingsModule {
    @Binds
    @Singleton
    abstract fun bindImageGenerationService(impl: RemoteImageGenerationService): ImageGenerationService
}
