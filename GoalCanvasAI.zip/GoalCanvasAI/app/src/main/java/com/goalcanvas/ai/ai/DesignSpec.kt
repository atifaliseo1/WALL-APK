package com.goalcanvas.ai.ai

/** Everything the renderer needs to draw one unique wallpaper. */
data class DesignSpec(
    val goals: List<String>,
    val quote: String,
    val backgroundStyle: BackgroundStyle,
    val artStyle: ArtStyle,
    val palette: ColorPalette,
    val typography: TypographySpec,
    val layout: LayoutSpec,
    val effects: EffectSpec,
    val imagePrompt: String, // full prompt sent to a remote image model, if configured
    val seed: Long
)

enum class BackgroundStyle(val label: String) {
    LUXURY_CARS("luxury sports car at night, wet asphalt reflections"),
    HYPERCAR("hypercar silhouette, studio rim lighting"),
    MOUNTAINS("misty mountain range at dawn"),
    SPACE("deep space nebula and stars"),
    SUNRISE("golden sunrise over the horizon"),
    SUNSET("dramatic orange sunset skyline"),
    DARK_AESTHETIC("moody dark minimal texture"),
    CYBERPUNK("neon cyberpunk alley, rain reflections"),
    MINIMALISM("clean minimal geometric shapes"),
    SAMURAI("lone samurai silhouette, fog"),
    LION("lion silhouette, golden hour"),
    EAGLE("eagle in flight, dramatic sky"),
    WOLF("wolf silhouette, moonlight"),
    ORIGINAL_HERO("original caped hero silhouette, city skyline"),
    BUSINESS_SUCCESS("modern glass office, success mood"),
    TRADING_CHARTS("abstract financial growth chart lines"),
    SKYSCRAPERS("skyscraper canyon, low angle"),
    BILLIONAIRE_OFFICE("penthouse office at night, city lights"),
    MONEY_AESTHETIC("abstract gold and green success texture"),
    ABSTRACT_ART("fluid abstract paint texture"),
    FIRE("intense fire and embers texture"),
    LIGHTNING("storm clouds with lightning strike"),
    RAIN("rain on window, city bokeh"),
    NEON_CITY("neon-lit city street at night"),
    LUXURY_WATCH("macro luxury watch mechanism"),
    MODERN_ARCHITECTURE("bold modern architecture, dramatic shadow"),
    FITNESS("athlete mid-motion, gym silhouette"),
    BOXING("boxer silhouette, dramatic rim light"),
    RUNNING("runner silhouette at sunrise"),
    CHESS("chess pieces, dramatic macro lighting"),
    ROCKET("rocket launch, exhaust trail"),
    STARS("star field, long exposure"),
    GALAXY("spiral galaxy, deep color"),
    AI_FUTURISTIC("futuristic AI generated abstract artwork");

    companion object {
        fun random() = entries.random()
    }
}

enum class ArtStyle(val descriptor: String) {
    DIGITAL_PAINTING("digital painting"),
    MATTE_PAINTING("matte painting"),
    CINEMATIC("cinematic lighting, film still"),
    REALISTIC("photorealistic render"),
    ANIME_INSPIRED("anime-inspired illustration, original style"),
    OIL_PAINTING("oil painting texture"),
    PENCIL_SKETCH("detailed pencil sketch"),
    FUTURISTIC("futuristic concept art"),
    HIGH_CONTRAST("high contrast dramatic"),
    VOLUMETRIC("volumetric lighting, depth of field");

    companion object {
        fun random() = entries.random()
    }
}

data class ColorPalette(
    val name: String,
    val backgroundGradient: List<Long>, // ARGB colors, top -> bottom (or angled)
    val accent: Long,
    val textPrimary: Long,
    val textSecondary: Long,
    val glow: Long
)

data class TypographySpec(
    val headlineFontFamily: FontChoice,
    val bodyFontFamily: FontChoice,
    val headlineSizeSp: Int,
    val bodySizeSp: Int,
    val letterSpacing: Float,
    val allCapsHeadline: Boolean,
    val rotationDegrees: Float
)

enum class FontChoice { SANS_BOLD, SANS_LIGHT, SERIF, SERIF_ITALIC, MONOSPACE, CONDENSED }

data class LayoutSpec(
    val composition: Composition,
    val goalsAsChecklist: Boolean,
    val quotePlacement: VerticalAnchor,
    val goalsPlacement: VerticalAnchor,
    val horizontalBias: Float // 0f = left, 0.5f = center, 1f = right
)

enum class Composition { CENTERED, RULE_OF_THIRDS_TOP, RULE_OF_THIRDS_BOTTOM, DIAGONAL, SPLIT }
enum class VerticalAnchor { TOP, UPPER_MIDDLE, CENTER, LOWER_MIDDLE, BOTTOM }

data class EffectSpec(
    val glowIntensity: Float,   // 0f..1f
    val shadowIntensity: Float, // 0f..1f
    val grainIntensity: Float,  // 0f..1f
    val vignette: Boolean,
    val noiseTexture: Boolean
)
