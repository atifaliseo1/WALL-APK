package com.goalcanvas.ai.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Fully offline background renderer. Produces a premium-feeling abstract/gradient composition
 * using only Canvas primitives - no network required. Used whenever remote AI generation is
 * unavailable, and also as the base layer the remote image (if any) is composited over.
 */
object LocalFallbackGenerator {

    fun render(spec: DesignSpec, widthPx: Int, heightPx: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val rnd = Random(spec.seed)
        val colors = spec.palette.backgroundGradient.map { it.toInt() }.toIntArray()

        // Angled linear gradient base - the angle varies per generation.
        val angle = rnd.nextFloat() * 2f * Math.PI.toFloat()
        val cx = widthPx / 2f
        val cy = heightPx / 2f
        val radius = kotlin.math.hypot(widthPx.toFloat(), heightPx.toFloat()) / 2f
        val x0 = cx - cos(angle) * radius
        val y0 = cy - sin(angle) * radius
        val x1 = cx + cos(angle) * radius
        val y1 = cy + sin(angle) * radius

        val basePaint = Paint().apply {
            shader = LinearGradient(x0, y0, x1, y1, colors, null, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), basePaint)

        // Soft glow blobs scattered around, count and position randomized per wallpaper.
        val glowCount = rnd.nextInt(2, 5)
        repeat(glowCount) {
            val bx = rnd.nextFloat() * widthPx
            val by = rnd.nextFloat() * heightPx
            val r = widthPx * (0.2f + rnd.nextFloat() * 0.35f)
            val glowPaint = Paint().apply {
                shader = RadialGradient(
                    bx, by, r,
                    intArrayOf(
                        (spec.palette.glow.toInt() and 0x55FFFFFF.toInt()),
                        0x00000000
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawCircle(bx, by, r, glowPaint)
        }

        // Fine grain / noise texture, if the spec calls for it.
        if (spec.effects.noiseTexture) {
            val noisePaint = Paint()
            val dotCount = (widthPx * heightPx / 4000)
            repeat(dotCount) {
                val nx = rnd.nextFloat() * widthPx
                val ny = rnd.nextFloat() * heightPx
                val alpha = (rnd.nextFloat() * 30 * spec.effects.grainIntensity * 10).toInt().coerceIn(0, 40)
                noisePaint.color = (alpha shl 24) or 0xFFFFFF
                canvas.drawCircle(nx, ny, 1f, noisePaint)
            }
        }

        // Vignette for cinematic depth.
        if (spec.effects.vignette) {
            val vignettePaint = Paint().apply {
                shader = RadialGradient(
                    cx, cy, radius,
                    intArrayOf(0x00000000, 0x99000000.toInt()),
                    floatArrayOf(0.6f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), vignettePaint)
        }

        return bitmap
    }
}
