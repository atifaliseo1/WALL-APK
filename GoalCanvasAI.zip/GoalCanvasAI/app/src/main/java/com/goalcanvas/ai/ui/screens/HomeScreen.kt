package com.goalcanvas.ai.ui.screens

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.goalcanvas.ai.ui.WallpaperViewModel
import com.goalcanvas.ai.ui.components.GoalInputList
import com.goalcanvas.ai.wallpaper.WallpaperTarget

@Composable
fun HomeScreen(
    onOpenHistory: () -> Unit,
    onOpenFavorites: () -> Unit,
    viewModel: WallpaperViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current

    LaunchedEffect(uiState.lastActionMessage, uiState.error) {
        (uiState.lastActionMessage ?: uiState.error)?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.consumeMessage()
        }
    }

    val widthPx = with(density) { configuration.screenWidthDp.dp.roundToPx() } * 2
    val heightPx = with(density) { configuration.screenHeightDp.dp.roundToPx() } * 2

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("GoalCanvas AI") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ElevatedCard(shape = RoundedCornerShape(20.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Today's goals", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "These become the wallpaper's checklist.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 8.dp))
                        GoalInputList(goals = uiState.goals, onGoalsChanged = viewModel::updateGoals)
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { viewModel.generate(widthPx, heightPx) },
                        enabled = !uiState.isGenerating,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (uiState.current == null) "Generate Wallpaper" else "Regenerate")
                    }
                }
            }

            if (uiState.isGenerating) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalArrangement = Arrangement.Center
                    ) { CircularProgressIndicator() }
                }
            }

            uiState.current?.let { generated ->
                item { WallpaperPreview(generated.bitmap) }
                item { WallpaperActionButtons(viewModel) }
                item {
                    Text(
                        text = "Style: ${generated.spec.backgroundStyle.name.replace('_', ' ')} · " +
                            "${generated.spec.artStyle.name.replace('_', ' ')}" +
                            if (!generated.usedRemoteAi) " (offline mode)" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onOpenHistory, modifier = Modifier.weight(1f)) { Text("History") }
                    OutlinedButton(onClick = onOpenFavorites, modifier = Modifier.weight(1f)) { Text("Favorites") }
                }
            }
        }
    }
}

@Composable
private fun WallpaperPreview(bitmap: Bitmap) {
    ElevatedCard(shape = RoundedCornerShape(20.dp)) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Wallpaper preview",
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(bitmap.width.toFloat() / bitmap.height.toFloat())
                .clip(RoundedCornerShape(20.dp))
        )
    }
}

@Composable
private fun WallpaperActionButtons(viewModel: WallpaperViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { viewModel.saveCurrent() }, modifier = Modifier.weight(1f)) { Text("Save") }
            OutlinedButton(onClick = { /* share intent wired in MainActivity */ }, modifier = Modifier.weight(1f)) {
                Text("Share")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { viewModel.setWallpaper(WallpaperTarget.HOME) }, modifier = Modifier.weight(1f)) {
                Text("Set Home")
            }
            OutlinedButton(onClick = { viewModel.setWallpaper(WallpaperTarget.LOCK) }, modifier = Modifier.weight(1f)) {
                Text("Set Lock")
            }
        }
        Button(
            onClick = { viewModel.setWallpaper(WallpaperTarget.BOTH) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Set Both") }
    }
}
