package com.goalcanvas.ai.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WallpaperDao {

    @Insert
    suspend fun insert(wallpaper: WallpaperEntity): Long

    @Update
    suspend fun update(wallpaper: WallpaperEntity)

    @Delete
    suspend fun delete(wallpaper: WallpaperEntity)

    @Query("SELECT * FROM wallpapers ORDER BY createdAtEpochMs DESC")
    fun observeAll(): Flow<List<WallpaperEntity>>

    @Query("SELECT * FROM wallpapers WHERE isFavorite = 1 ORDER BY createdAtEpochMs DESC")
    fun observeFavorites(): Flow<List<WallpaperEntity>>

    @Query("SELECT COUNT(*) FROM wallpapers")
    suspend fun count(): Int

    // Keep only the newest 30 non-favorited entries; favorites are exempt from history pruning.
    @Query(
        """
        DELETE FROM wallpapers
        WHERE isFavorite = 0
        AND id NOT IN (
            SELECT id FROM wallpapers WHERE isFavorite = 0
            ORDER BY createdAtEpochMs DESC LIMIT 30
        )
        """
    )
    suspend fun pruneBeyondThirty()
}
