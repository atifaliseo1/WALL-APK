package com.goalcanvas.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun GoalInputList(
    goals: List<String>,
    onGoalsChanged: (List<String>) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        goals.forEachIndexed { index, goal ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = goal,
                    onValueChange = { newValue ->
                        onGoalsChanged(goals.toMutableList().also { it[index] = newValue })
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("Goal ${index + 1}") }
                )
                IconButton(onClick = {
                    onGoalsChanged(goals.toMutableList().also { it.removeAt(index) })
                }) {
                    Icon(Icons.Default.Close, contentDescription = "Remove goal")
                }
            }
        }

        TextButton(onClick = { onGoalsChanged(goals + "") }) {
            Icon(Icons.Default.Add, contentDescription = null)
            Text("  Add goal")
        }
    }
}
