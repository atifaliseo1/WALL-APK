package com.goalcanvas.ai.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [WallpaperEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wallpaperDao(): WallpaperDao
}
