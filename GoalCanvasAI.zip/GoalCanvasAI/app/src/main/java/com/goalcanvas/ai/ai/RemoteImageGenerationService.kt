package com.goalcanvas.ai.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Calls a configurable text-to-image HTTP API to generate the wallpaper background.
 * Configure [ApiConfig.baseUrl] and [ApiConfig.apiKey] with your provider of choice
 * (e.g. Stability AI's stable-image endpoint, or your own proxy). Nothing here is
 * hardcoded to a specific vendor's contract beyond a generic
 * `{ "prompt": ..., "width": ..., "height": ... }` JSON body returning a base64 image -
 * adapt [buildRequestBody] / [parseResponse] to your chosen provider's actual schema.
 *
 * On ANY failure (no key configured, no network, timeout, bad response) this returns
 * null so the caller falls back to [LocalFallbackGenerator] and the user still gets a
 * finished wallpaper.
 */
object ApiConfig {
    // Fill these in with your own provider details. Leave apiKey blank to force offline mode.
    const val baseUrl: String = "" // e.g. "https://api.your-image-provider.com/v1/generate"
    const val apiKey: String = ""
}

@Singleton
class RemoteImageGenerationService @Inject constructor() : ImageGenerationService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun generateBackground(spec: DesignSpec, widthPx: Int, heightPx: Int): BackgroundResult {
        val fallback = { BackgroundResult.Fallback(LocalFallbackGenerator.render(spec, widthPx, heightPx)) }

        if (ApiConfig.baseUrl.isBlank() || ApiConfig.apiKey.isBlank()) {
            return fallback()
        }

        return withContext(Dispatchers.IO) {
            try {
                val body = buildRequestBody(spec, widthPx, heightPx)
                val request = Request.Builder()
                    .url(ApiConfig.baseUrl)
                    .addHeader("Authorization", "Bearer ${ApiConfig.apiKey}")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext fallback()
                    val json = response.body?.string() ?: return@withContext fallback()
                    val bitmap = parseResponse(json) ?: return@withContext fallback()
                    BackgroundResult.Remote(bitmap)
                }
            } catch (t: Throwable) {
                // Network unavailable, provider error, malformed response, etc. Never crash the flow.
                fallback()
            }
        }
    }

    private fun buildRequestBody(spec: DesignSpec, widthPx: Int, heightPx: Int): JSONObject =
        JSONObject().apply {
            put("prompt", spec.imagePrompt)
            put("width", widthPx)
            put("height", heightPx)
            put("seed", spec.seed)
        }

    /** Adapt this to your provider's actual response schema. Expects a base64 PNG/JPEG under "image". */
    private fun parseResponse(json: String): Bitmap? {
        val obj = JSONObject(json)
        val base64 = obj.optString("image", "")
        if (base64.isBlank()) return null
        val bytes = Base64.decode(base64, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }
}
