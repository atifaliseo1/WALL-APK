package com.goalcanvas.ai.ui

import android.graphics.Bitmap
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.goalcanvas.ai.data.local.WallpaperEntity
import com.goalcanvas.ai.data.repository.GeneratedWallpaper
import com.goalcanvas.ai.data.repository.WallpaperRepository
import com.goalcanvas.ai.wallpaper.WallpaperManagerHelper
import com.goalcanvas.ai.wallpaper.WallpaperTarget
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class GoalCanvasUiState(
    val goals: List<String> = listOf("Close 3 clients", "Pray 5 times", "Go to the gym", "Read 30 pages", "Drink 3L water"),
    val isGenerating: Boolean = false,
    val current: GeneratedWallpaper? = null,
    val error: String? = null,
    val lastActionMessage: String? = null
)

@HiltViewModel
class WallpaperViewModel @Inject constructor(
    private val repository: WallpaperRepository,
    private val wallpaperManagerHelper: WallpaperManagerHelper
) : ViewModel() {

    private val _uiState = MutableStateFlow(GoalCanvasUiState())
    val uiState: StateFlow<GoalCanvasUiState> = _uiState

    val history: StateFlow<List<WallpaperEntity>> =
        repository.observeHistory().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<WallpaperEntity>> =
        repository.observeFavorites().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateGoals(goals: List<String>) {
        _uiState.value = _uiState.value.copy(goals = goals.filter { it.isNotBlank() })
    }

    /** Generates a brand-new wallpaper design. Call again ("Regenerate") for a completely different result. */
    fun generate(widthPx: Int, heightPx: Int) {
        val goals = _uiState.value.goals
        if (goals.isEmpty()) {
            _uiState.value = _uiState.value.copy(error = "Add at least one goal first.")
            return
        }
        _uiState.value = _uiState.value.copy(isGenerating = true, error = null)
        viewModelScope.launch {
            try {
                val result = repository.generate(goals, widthPx, heightPx)
                _uiState.value = _uiState.value.copy(isGenerating = false, current = result)
            } catch (t: Throwable) {
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    error = "Couldn't generate a wallpaper: ${t.message ?: "unknown error"}"
                )
            }
        }
    }

    fun saveCurrent() {
        val current = _uiState.value.current ?: return
        viewModelScope.launch {
            repository.saveToHistory(current)
            _uiState.value = _uiState.value.copy(lastActionMessage = "Saved to history")
        }
    }

    fun setWallpaper(target: WallpaperTarget) {
        val bitmap = _uiState.value.current?.bitmap ?: return
        wallpaperManagerHelper.apply(bitmap, target)
        _uiState.value = _uiState.value.copy(
            lastActionMessage = when (target) {
                WallpaperTarget.HOME -> "Home screen wallpaper set"
                WallpaperTarget.LOCK -> "Lock screen wallpaper set"
                WallpaperTarget.BOTH -> "Home and lock screen wallpaper set"
            }
        )
    }

    fun toggleFavorite(entity: WallpaperEntity) {
        viewModelScope.launch { repository.toggleFavorite(entity) }
    }

    fun deleteFromHistory(entity: WallpaperEntity) {
        viewModelScope.launch { repository.delete(entity) }
    }

    fun consumeMessage() {
        _uiState.value = _uiState.value.copy(lastActionMessage = null, error = null)
    }

    fun currentBitmap(): Bitmap? = _uiState.value.current?.bitmap
}
