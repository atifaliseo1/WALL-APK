package com.goalcanvas.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallpapers")
data class WallpaperEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val filePath: String,
    val goalsJoined: String,
    val quote: String,
    val createdAtEpochMs: Long,
    val isFavorite: Boolean = false,
    val backgroundStyle: String,
    val artStyle: String
)
